import os
import tempfile
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from predict4 import load_model, predict, device  # your code

# ---------------- Env & model loading ----------------

WEIGHTS_PATH = os.environ.get("WP")
if WEIGHTS_PATH is None:
    raise RuntimeError(
        "Environment variable WP is not set. "
        "Export it to point to your .pt weights file."
    )

WEIGHTS_PATH = str(Path(WEIGHTS_PATH).expanduser())

if not Path(WEIGHTS_PATH).exists():
    raise RuntimeError(f"WP points to non-existent file: {WEIGHTS_PATH}")

print(f"Loading model from: {WEIGHTS_PATH}")
MODEL = load_model(WEIGHTS_PATH, device)

# ---------------- FastAPI app ----------------

app = FastAPI(title="Breast AI Inference API")

# Allow calls from any frontend origin (you can restrict later)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/api/predict")
async def predict_endpoint(file: UploadFile = File(...)):
    """
    Accepts a JPG/PNG mammogram, saves to a temporary file,
    and runs your ConvNeXt+SignalProc+KAN model.
    """
    if file.content_type not in ("image/jpeg", "image/png", "image/jpg"):
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported content type: {file.content_type}. "
                   f"Please upload a JPG or PNG image."
        )

    suffix = ".jpg" if "jpeg" in file.content_type or "jpg" in file.content_type else ".png"

    try:
        # Save upload to a temp file so your existing pipeline can use image_path
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp_path = Path(tmp.name)
            contents = await file.read()
            tmp.write(contents)

        # Run your existing predict() which expects a path
        label, prob = predict(MODEL, str(tmp_path), device)

        return {
            "label": label,
            "probability": prob,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Inference error: {e}")
    finally:
        try:
            if "tmp_path" in locals() and tmp_path.exists():
                tmp_path.unlink()
        except Exception:
            # Best-effort cleanup; ignore errors
            pass
