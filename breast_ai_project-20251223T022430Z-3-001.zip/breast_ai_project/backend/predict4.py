# predict2_final.py — ConvNeXt-small + SignalProc + KAN head inference

import math
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm
import cv2

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)


def count_params(m: nn.Module) -> int:
    return sum(p.numel() for p in m.parameters() if p.requires_grad)


# -------------------------------------------------------------------------
#  Signal processing blocks (same as checkpoint)
# -------------------------------------------------------------------------

class WaveletPool2D(nn.Module):
    def __init__(self):
        super().__init__()
        k = torch.tensor([[1., 1.],
                          [1., 1.]]) / 2.0
        self.register_buffer("kernel", k.view(1, 1, 2, 2))

    def forward(self, x):
        B, C, H, W = x.shape
        w = self.kernel.expand(C, 1, 2, 2)
        return F.conv2d(x, w, stride=2, padding=0, groups=C)


class SignalPreprocess2D(nn.Module):
    def __init__(self):
        super().__init__()
        self.wavelet = WaveletPool2D()

        hp = torch.tensor([[0., -1., 0.],
                           [-1., 4., -1.],
                           [0., -1., 0.]]) / 4.0

        sx = torch.tensor([[-1., 0., 1.],
                           [-2., 0., 2.],
                           [-1., 0., 1.]]) / 4.0

        sy = torch.tensor([[-1., -2., -1.],
                           [0., 0., 0.],
                           [1., 2., 1.]]) / 4.0

        self.register_buffer("kernel_hp", hp.view(1, 1, 3, 3))
        self.register_buffer("kernel_sx", sx.view(1, 1, 3, 3))
        self.register_buffer("kernel_sy", sy.view(1, 1, 3, 3))

    def forward(self, x):
        intensity = x[:, 0:1]
        hull = x[:, 1:2]

        low = self.wavelet(intensity)

        hp_full = F.conv2d(intensity, self.kernel_hp, padding=1)
        hp_ds = self.wavelet(hp_full)

        gx = F.conv2d(intensity, self.kernel_sx, padding=1)
        gy = F.conv2d(intensity, self.kernel_sy, padding=1)
        grad_mag = torch.sqrt(gx * gx + gy * gy + 1e-6)
        grad_ds = self.wavelet(grad_mag)

        return torch.cat([low, hp_ds, grad_ds], dim=1)   # (B,3,256,256)


# -------------------------------------------------------------------------
#  KAN HEAD
# -------------------------------------------------------------------------

class RobustSpline1D(nn.Module):
    def __init__(self, in_dim: int, K: int = 3):
        super().__init__()
        self.in_dim, self.K = in_dim, K
        centers = torch.linspace(-1.0, 1.0, K).view(1, 1, K)
        self.register_buffer("centers", centers)
        self.h = 2.0 / (K - 1 + 1e-8)

    def forward(self, x):
        x_norm = torch.tanh(x)
        z = x_norm.unsqueeze(-1)
        phi = F.relu(1.0 - torch.abs((z - self.centers) / self.h))
        return phi.reshape(x.size(0), self.in_dim * self.K)


# -------------------------------------------------------------------------
#  MAIN MODEL
# -------------------------------------------------------------------------

class ConvNeXtSigProcHullKANSmall(nn.Module):
    def __init__(self, in_ch_convnext=3, backbone_name="convnext_small",
                 kan_hidden=256, spline_K=3, p_drop=0.5):
        super().__init__()
        self.sigproc = SignalPreprocess2D()

        self.backbone = timm.create_model(
            backbone_name,
            pretrained=True,
            in_chans=in_ch_convnext,
            num_classes=0,
            global_pool="",
        )
        self.num_features = self.backbone.num_features  # usually 768

        self.kan_spline = RobustSpline1D(self.num_features, K=spline_K)
        kan_in = self.num_features * (1 + spline_K)

        self.kan_ln = nn.LayerNorm(kan_in)
        self.kan_act = nn.GELU()
        self.kan_drop = nn.Dropout(p_drop)
        self.kan_out = nn.Linear(kan_in, 1)

    def forward_backbone_features(self, x):
        feat = self.backbone.forward_features(x)
        if feat.dim() == 4:
            return feat
        else:
            raise RuntimeError("Unexpected backbone output")

    def forward(self, x):
        x_conv = self.sigproc(x)
        feat = self.forward_backbone_features(x_conv)
        feat_vec = feat.mean(dim=(2, 3))
        spline_feat = self.kan_spline(feat_vec)
        h = torch.cat([feat_vec, spline_feat], dim=1)
        h = self.kan_ln(h)
        h = self.kan_act(h)
        h = self.kan_drop(h)
        logit = self.kan_out(h).squeeze(-1)
        return logit


# -------------------------------------------------------------------------
#  Preprocessing (CLAHE, crop, resize) → 512×512 float32
# -------------------------------------------------------------------------

IMG_SIZE = 512
_clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

def largest_breast_crop_box(img_u8: np.ndarray, margin_frac: float = 0.05):
    _, th = cv2.threshold(img_u8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=2)

    num, _, stats, _ = cv2.connectedComponentsWithStats(th)
    if num <= 1:
        h, w = img_u8.shape
        return 0, 0, w, h

    areas = stats[1:, 4]
    idx = 1 + int(np.argmax(areas))
    x, y, w, h, _ = stats[idx]

    mx, my = int(margin_frac * w), int(margin_frac * h)
    x0, y0 = max(x - mx, 0), max(y - my, 0)
    x1 = min(x + w + mx, img_u8.shape[1])
    y1 = min(y + h + my, img_u8.shape[0])
    return x0, y0, x1, y1


def preprocess_mammo_to_512(image_path: str) -> np.ndarray:
    img = cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError(f"Could not load {image_path}")

    img_f = img.astype(np.float32)
    img_f -= img_f.min()
    img_f /= (img_f.max() + 1e-6)
    img_u8 = (img_f * 255).astype(np.uint8)

    x0, y0, x1, y1 = largest_breast_crop_box(img_u8)
    img_crop = img_u8[y0:y1, x0:x1]

    img_clahe = _clahe.apply(img_crop)
    img_res = cv2.resize(img_clahe, (IMG_SIZE, IMG_SIZE))

    img_res = img_res.astype(np.float32) / 255.0
    return img_res   # (H,W) float32


# -------------------------------------------------------------------------
#  intensity + hull generator from PREPROCESSED 512×512 image
# -------------------------------------------------------------------------

def generate_intensity_and_hull_from_512(img_512: np.ndarray):
    intensity = img_512.astype("float32")

    blur = cv2.GaussianBlur((img_512 * 255).astype(np.uint8), (31, 31), 0)
    thr = cv2.adaptiveThreshold(
        blur, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        51, 5
    )
    thr = 255 - thr

    cnts, _ = cv2.findContours(thr, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    hull_mask = np.zeros_like(thr, dtype=np.float32)
    if cnts:
        largest = max(cnts, key=cv2.contourArea)
        hull = cv2.convexHull(largest)
        cv2.fillConvexPoly(hull_mask, hull, 1.0)

    intensity_t = torch.tensor(intensity).unsqueeze(0).unsqueeze(0)
    hull_t = torch.tensor(hull_mask).unsqueeze(0).unsqueeze(0)
    return intensity_t, hull_t


# -------------------------------------------------------------------------
#  Load model + predict
# -------------------------------------------------------------------------

def load_model(weights_path: str, device: torch.device):
    model = ConvNeXtSigProcHullKANSmall().to(device)
    state = torch.load(weights_path, map_location=device)
    model.load_state_dict(state, strict=True)
    model.eval()
    print(f"Loaded model with {count_params(model):,} params.")
    return model


def predict(model, image_path: str, device: torch.device):
    img512 = preprocess_mammo_to_512(image_path)
    intensity, hull = generate_intensity_and_hull_from_512(img512)

    x = torch.cat([intensity, hull], dim=1).to(device)

    with torch.no_grad():
        logit = model(x)
        prob = torch.sigmoid(logit).item()

    label = "Malignant" if prob >= 0.5 else "Benign"
    return label, prob


# -------------------------------------------------------------------------
#  CLI
# -------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--weights", required=True)
    parser.add_argument("--image", required=True)
    args = parser.parse_args()

    model = load_model(args.weights, device)
    print("Running prediction...")

    label, prob = predict(model, args.image, device)
    print(f"\nPrediction: {label} (prob={prob:.4f})\n")
