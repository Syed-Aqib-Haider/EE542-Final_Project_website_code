console.log("🔥 RESULTS.JS LOADED SUCCESSFULLY 🔥");
window.RESULTS_JS_LOADED = true;

document.addEventListener("DOMContentLoaded", () => {

  // Read Base64 from sessionStorage
  const storedImg = sessionStorage.getItem("uploadedImage");
  console.log("Loaded Base64:", storedImg ? storedImg.substring(0, 40) : "NULL");

  // Set preview square background
  if (storedImg) {
    document.getElementById("resultImageBox").style.backgroundImage = `url('${storedImg}')`;
  }

  // Read URL params
  const params = new URLSearchParams(window.location.search);
  const label = params.get("label") || "--";
  const prob = parseFloat(params.get("prob") || "0");

  // Update label
  document.getElementById("resultLabel").innerText = `Result: ${label}`;

  // Confidence %
  const pct = (prob * 100).toFixed(1) + "%";
  document.getElementById("confValue").innerText = pct;
  document.getElementById("confBar").style.width = pct;

  // Green pill for benign
  if (label.toLowerCase() === "benign") {
    const pill = document.getElementById("resultPill");
    pill.classList.remove("bg-red-100", "text-red-600");
    pill.classList.add("bg-green-100", "text-green-600");
  }

});
