// frontend/js/upload.js

const browseBtn = document.getElementById("browseButton");
const startBtn  = document.getElementById("startAnalysisBtn");
const fileInput = document.getElementById("fileInput");
const fileName  = document.getElementById("fileName");
const preview   = document.getElementById("previewImage");

const API_URL = "http://136.118.169.96:8005/api/predict";

let selectedFile = null;
let base64Image = null;

// Open file picker
browseBtn.addEventListener("click", () => fileInput.click());

// Handle selection
fileInput.addEventListener("change", () => {
  if (!fileInput.files || !fileInput.files[0]) return;

  selectedFile = fileInput.files[0];
  fileName.innerText = selectedFile.name;
  startBtn.disabled = false;

  // Generate Base64 preview
  const reader = new FileReader();
  reader.onload = function(e) {
    base64Image = e.target.result;
    console.log("Base64 generated:", base64Image.substring(0, 40));

    preview.src = base64Image;
    preview.classList.remove("hidden");
  };
  reader.readAsDataURL(selectedFile);
});

// Submit to backend
startBtn.addEventListener("click", async () => {
  startBtn.disabled = true;
  startBtn.innerText = "Analyzing...";

  const formData = new FormData();
  formData.append("file", selectedFile);

 try {
    console.log("Sending to backend:", API_URL);

    const res = await fetch(API_URL, {
        method: "POST",
        body: formData
    });

    console.log("Response OK?", res.ok, "Status:", res.status);

    if (!res.ok) {
        const errText = await res.text();
        console.error("Backend ERROR:", errText);
        alert("Backend ERROR:\n" + errText);
        startBtn.disabled = false;
        startBtn.innerText = "Start AI Analysis";
        return;
    }

    const data = await res.json();
    console.log("Backend returned:", data);

    // Save Base64
    console.log("Saving image to sessionStorage");
    sessionStorage.setItem("uploadedImage", base64Image);

    // Build redirect URL
    const probValue = data.probability ?? data.prob ?? 0;
    //const url = `results.html?label=${encodeURIComponent(data.label)}&prob=${encodeURIComponent(probValue)}`;
    const url = `http://136.118.169.96:8080/results.html?label=${encodeURIComponent(data.label)}&prob=${encodeURIComponent(probValue)}`;
    

    console.log("Redirecting to:", url);
    window.location.href = url;

    } catch (err) {
    console.error("Catch ERROR:", err);
    alert("Catch ERROR:\n" + err);
    startBtn.disabled = false;
    startBtn.innerText = "Start AI Analysis";
                 }

});
